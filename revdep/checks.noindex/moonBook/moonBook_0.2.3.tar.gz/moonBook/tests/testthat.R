library(testthat)
library(moonBook)

test_check("moonBook")
